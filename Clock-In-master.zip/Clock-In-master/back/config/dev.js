module.exports = {
  "dbURL": "mongodb+srv://theUser:thePass@cluster0.jtvmy.mongodb.net/test?retryWrites=true&w=majority",
  // "dbURL": "mongodb://localhost:27017",
}
