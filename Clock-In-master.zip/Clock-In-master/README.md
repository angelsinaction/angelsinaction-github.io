![logo](https://res.cloudinary.com/dojmo7vcc/image/upload/v1607726258/clock/front-page-logo_bcsfkd.jpg)

[█ Live Demo █](https://clockin-demo.com/)

# Clock-In
- A modern employee management system

# Run Locally:
- run `npm i` in both back and front folders
- put the pass.js in the correct folder (will be provided by Slack)
- run `npm start` in both back and front folders
