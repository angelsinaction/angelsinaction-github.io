export function loading() {
  return { type: 'LOADING_START' }
}
export function doneLoading() {
  return { type: 'LOADING_DONE' }
}