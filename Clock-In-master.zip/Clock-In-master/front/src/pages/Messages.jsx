import React from "react";

const Messages = () => {
  return <h1> Messages</h1>;
};

export default Messages;
